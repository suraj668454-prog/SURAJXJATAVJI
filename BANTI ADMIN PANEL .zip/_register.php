

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN PANEL | CREATE ACCOUNT</title>
    <script src="https://cdn.jsdelivr.net/npm/particles.js"></script>
    <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
    <style>
        :root {
            --cyan: #00f2fe;
            --blue: #00d2ff;
            --bg: #050505;
            --card-bg: #0d1117;
        }

        body, html {
            margin: 0; padding: 0; height: 100%;
            background-color: var(--bg);
            font-family: 'Public Sans', sans-serif;
            overflow: hidden;
            display: flex; justify-content: center; align-items: center;
        }

        #particles-js { position: fixed; width: 100%; height: 100%; z-index: 1; }

        /* Loader Styles */
        #loader-screen {
            position: fixed; inset: 0; background: var(--bg); z-index: 9999;
            display: flex; justify-content: center; align-items: center;
        }
        .validation-box {
            width: 320px; text-align: center; background: #0d1117; 
            padding: 40px; border-radius: 25px; border: 1px solid #222;
            box-shadow: 0 0 50px rgba(0, 242, 254, 0.15);
        }
        .validation-title { color: var(--cyan); font-size: 20px; font-weight: 900; letter-spacing: 3px; margin-bottom: 25px; text-transform: uppercase; }
        .circle-loader {
            width: 70px; height: 70px; border-radius: 50%; border: 4px solid rgba(0, 242, 254, 0.1);
            border-top: 4px solid var(--cyan); margin: 0 auto 25px; animation: spin 0.7s linear infinite;
        }
        .status-txt { color: #888; font-size: 13px; margin-bottom: 15px; font-family: monospace; letter-spacing: 1px; }
        .progress-container { width: 100%; height: 6px; background: #1a1a1c; border-radius: 10px; overflow: hidden; }
        .progress-bar { width: 0%; height: 100%; background: var(--cyan); transition: width 0.1s linear; }
        @keyframes spin { 100% { transform: rotate(360deg); } }

        /* Form Container */
        .auth-container {
            display: none; position: relative; z-index: 10;
            width: 290px; padding: 40px 25px; 
            background: var(--card-bg); border-radius: 25px;
            text-align: center; overflow: hidden;
            box-shadow: 0 0 40px rgba(0, 242, 254, 0.2);
            animation: jumpCard 4s ease-in-out infinite;
        }

        @keyframes jumpCard { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }

        .auth-container::before {
            content: ''; position: absolute; top: -50%; left: -50%; width: 200%; height: 200%;
            background: conic-gradient(transparent, transparent, transparent, var(--cyan));
            animation: rotateLighting 3s linear infinite; z-index: -1;
        }
        .auth-container::after {
            content: ''; position: absolute; inset: 3px; 
            background: var(--card-bg); border-radius: 22px; z-index: -1;
        }

        @keyframes rotateLighting { 100% { transform: rotate(360deg); } }

        .scanner-orb {
            position: relative; width: 50px; height: 50px; margin: 0 auto 10px;
            display: flex; justify-content: center; align-items: center;
        }
        .orb-ring {
            position: absolute; width: 100%; height: 100%;
            border-radius: 50%; border: 2px dashed var(--cyan);
            animation: spinCircle 6s linear infinite; opacity: 0.5;
        }
        @keyframes spinCircle { 100% { transform: rotate(360deg); } }

        .brand-logo { 
            font-size: 20px; font-weight: 900; color: #fff; letter-spacing: 2px; text-transform: uppercase;
            text-shadow: 0 0 10px var(--cyan);
        }
        .brand-logo span { color: var(--cyan); }
        .sub-tag { font-size: 10px; color: #fff; opacity: 0.7; letter-spacing: 2px; margin-bottom: 15px; }

        .form-input {
            width: 100%; background: #010409;
            border: 1px solid #30363d; padding: 10px; border-radius: 10px;
            color: white; outline: none; margin-top: 10px; box-sizing: border-box;
            font-size: 11px; transition: 0.3s;
        }
        .form-input:focus { border-color: var(--cyan); box-shadow: 0 0 10px var(--cyan); }

        /* Turnstile scaling for small card */
        .cf-turnstile { margin-top: 15px; display: flex; justify-content: center; transform: scale(0.8); }

        .btn-wrapper { margin-top: 15px; display: flex; justify-content: center; height: 40px; }
        .btn-register {
            width: 100%; height: 40px; border: none; border-radius: 10px;
            background: linear-gradient(135deg, var(--blue), var(--cyan));
            color: #000; font-weight: 900; cursor: pointer;
            text-transform: uppercase; transition: all 0.5s; font-size: 12px;
        }
        .btn-register.active-loading { width: 40px; border-radius: 50%; color: transparent; }
        .btn-register.active-loading::after {
            content: ""; position: absolute; width: 18px; height: 18px;
            top: 50%; left: 50%; margin: -9px 0 0 -9px;
            border: 3px solid rgba(0,0,0,0.1); border-top: 3px solid #000;
            border-radius: 50%; animation: spinCircle 0.6s linear infinite;
        }

        .footer-txt { margin-top: 20px; font-size: 11px; color: #888; }
        .footer-txt a { color: var(--cyan); text-decoration: none; }
    </style>
</head>
<body>

    <div id="loader-screen">
        <div class="validation-box">
            <div class="validation-title">SECURE REGISTRATION</div>
            <div class="circle-loader"></div>
            <div id="status-msg" class="status-txt">Initializing secure link...</div>
            <div class="progress-container"><div id="p-bar" class="progress-bar"></div></div>
        </div>
    </div>

    <div id="particles-js"></div>

    <div class="auth-container" id="reg-ui">
        <div class="scanner-orb">
            <div class="orb-ring"></div>
            <div style="font-size: 24px;">🛡️</div>
        </div>

        <div class="brand-logo">ADMIN <span>PANEL</span></div>
        <div class="sub-tag">CREATE ACCOUNT</div>

                
        <form method="POST" id="regForm">
            <input type="text" name="username" class="form-input" placeholder="USER NAME" required>
            <input type="email" name="email" class="form-input" placeholder="EMAIL ADDRESS" required>
            <input type="password" name="password" class="form-input" placeholder="PASSWORD" required>
            <input type="password" name="confirm_password" class="form-input" placeholder="CONFIRM PASSWORD" required>
            <input type="text" name="referred_by" class="form-input" placeholder="REFERRAL CODE" value="">
            
            <div class="cf-turnstile" data-sitekey="0x4AAAAAACNq2xPjhg12740t" data-theme="dark"></div>

            <div class="btn-wrapper">
                <button type="submit" class="btn-register" id="regBtn">REGISTER NOW</button>
            </div>
        </form>

        <div class="footer-txt">Already Member? <a href="login.php">Login Now</a></div>
    </div>

    <script>
        window.onload = function() {
            let progress = 0;
            const bar = document.getElementById('p-bar');
            const msg = document.getElementById('status-msg');
            const interval = setInterval(() => {
                progress += 10;
                bar.style.width = progress + "%";
                if(progress == 40) msg.innerText = "Securing connection...";
                if(progress == 80) msg.innerText = "Loading captcha module...";
                if (progress >= 100) {
                    clearInterval(interval);
                    setTimeout(() => {
                        document.getElementById('loader-screen').style.display = 'none';
                        document.getElementById('reg-ui').style.display = 'block';
                    }, 200);
                }
            }, 80); 
        };

        document.getElementById('regForm').onsubmit = function() {
            const btn = document.getElementById('regBtn');
            btn.classList.add('active-loading');
            btn.innerText = ""; 
        };

        particlesJS("particles-js", { 
            "particles": { "number": { "value": 30 }, "color": { "value": "#00f2fe" }, "move": { "speed": 1 } } 
        });
    </script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v833ccba57c9e4d2798f2e76cebdd09a11778172276447" integrity="sha512-57MDmcccJXYtNnH+ZiBwzC4jb2rvgVCEokYN+L/nLlmO8rfYT/gIpW2A569iJ/3b+0UEasghjuZH/ma3wIs/EQ==" data-cf-beacon='{"version":"2024.11.0","token":"6f8bd6c1bb554ccea418ec840fe44747","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>
</html>

